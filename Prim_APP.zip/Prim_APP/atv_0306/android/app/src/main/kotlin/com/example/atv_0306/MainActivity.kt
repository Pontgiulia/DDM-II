package com.example.atv_0306

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
