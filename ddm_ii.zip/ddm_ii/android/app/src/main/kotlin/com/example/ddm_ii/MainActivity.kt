package com.example.ddm_ii

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
