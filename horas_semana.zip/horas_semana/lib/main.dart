import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Rotina',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color.fromARGB(255, 222, 56, 169)),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Horas da semana'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  String? diaSelecionado;

  final Map<String, List<String>> horarios = {
    'Segunda': ['07:30 - Geografia', '09:10 - História', '10:00 - Intervalo', '10:20 - História','11:10 - Gestão de projeto web', '12:50 - Saída'],
    'Terça': ['07:30 - Português', '09:10 - TCC', '10:00 - Intervalo', '10:20 - TCC','11:10 - SW-II', '12:50 - Saída'],
    'Quarta': ['07:30 - Internet das coisas', '09:10 - Desenvolvimento de dispositivos móveis', '10:00 - Intervalo', '10:20 - Desenvolvimento de dispositivos móveis','11:10 - Matemática', '12:50 - Saída'],
    'Quinta': ['07:30 - Computação em nuvem para web', '09:10 - Inglês', '10:00 - Intervalo', '10:20 - Inglês','11:10 - Espanhol', '12:50 - Saída'],
    'Sexta': ['07:30 - Acessibilidade', '09:10 - Português', '10:00 - Intervalo', '10:20 - Matemática','11:10 - Filosofia/Sociologia', '12:50 - Saída'],
    'Sábado': ['09:00 - Pequenos talentos'],
    'Domingo': ['Descanso'],
  };

  void selecionarDia(String dia) {
    setState(() {
      diaSelecionado = dia;
    });
  }

  Widget buildDiaButton(String dia, Color cor) {
    return ElevatedButton(
      onPressed: () => selecionarDia(dia),
      style: ElevatedButton.styleFrom(
        backgroundColor: cor,
        foregroundColor: Colors.white,
        minimumSize: const Size(90, 50), // ← aumenta o tamanho dos botões
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
        ),
        textStyle: const TextStyle(
          fontSize: 14, // ← texto maior
          fontWeight: FontWeight.bold,
        ),
      ),
      child: Text(dia),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text(widget.title),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // 🔹 Botões centralizados e na parte de cima
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center, // centraliza horizontalmente
                children: [
                  buildDiaButton('Segunda', const Color.fromARGB(255, 176, 16, 107)),
                  const SizedBox(width: 8),
                  buildDiaButton('Terça', const Color.fromARGB(255, 190, 20, 94)),
                  const SizedBox(width: 8),
                  buildDiaButton('Quarta', const Color.fromARGB(255, 176, 16, 107)),
                  const SizedBox(width: 8),
                  buildDiaButton('Quinta', const Color.fromARGB(255, 190, 20, 94)),
                  const SizedBox(width: 8),
                  buildDiaButton('Sexta', const Color.fromARGB(255, 176, 16, 107)),
                  const SizedBox(width: 8),
                  buildDiaButton('Sábado', const Color.fromARGB(255, 190, 20, 94)),
                  const SizedBox(width: 8),
                  buildDiaButton('Domingo', const Color.fromARGB(255, 176, 16, 107)),
                ],
              ),
            ),
            const SizedBox(height: 25),

            // 🔹 Mostra os horários conforme o dia selecionado
            Expanded(
              child: diaSelecionado == null
                  ? const Center(
                      child: Text(
                        "Selecione um dia da semana para ver seus horários.",
                        style: TextStyle(fontSize: 16, fontStyle: FontStyle.italic),
                      ),
                    )
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "Horários de $diaSelecionado:",
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Expanded(
                          child: ListView(
                            children: horarios[diaSelecionado]!
                                .map(
                                  (h) => Card(
                                    color: Colors.pink[50],
                                    child: ListTile(
                                      leading: const Icon(Icons.schedule, color: Colors.pink),
                                      title: Text(h),
                                    ),
                                  ),
                                )
                                .toList(),
                          ),
                        ),
                      ],
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
