package com.example.horas_semana

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
